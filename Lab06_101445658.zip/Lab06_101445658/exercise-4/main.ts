import { Customer } from "./customer";

let customer = new Customer("John", "Doe", 30);
customer.greeter();
customer.GetAge();